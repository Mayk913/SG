// import { TeacherI } from "../user/teacher";
export interface MincienciaCategoryI {
    id?: number;
    name: string;
    createdAt?:string
    // Teachers?:TeacherI[]
}