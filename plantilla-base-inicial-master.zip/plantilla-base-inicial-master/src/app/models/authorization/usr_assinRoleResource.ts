export interface assinRoleResourceI{
    id?:number;
    RecursosRoles:[
      {
      ResourceId: string; 
      RoleId:string;
      }
    ]
    
  }