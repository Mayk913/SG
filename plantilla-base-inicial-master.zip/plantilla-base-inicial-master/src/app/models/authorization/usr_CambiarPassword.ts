export interface CambiarPasswordI{
    id?: number;
    oldPassword:string;
    newPassword:string;
}