export interface MaintenanceI {
    id?: number
    name:string
    url:string
    date:string
    status_maintenance:string
}