export const environment = {
  production: true,
  // API_URI : 'http://localhost:3000',
  API_URI : 'http://181.78.22.118/appgesproy/backend'
};
